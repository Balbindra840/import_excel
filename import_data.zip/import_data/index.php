<?php session_start();
$con = mysqli_connect("localhost", "root", "", "import_data");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Import Data From Excel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <div class="container">
        <h2>Importing data From Excel (CVS, xls, xlsx)</h2>
        <div class="row">
            <?php
            if (isset($_SESSION['status'])) {
                echo "<h4>" . $_SESSION['status'] . "</h4>";
                unset($_SESSION['status']);
            }
            ?>
            <div class="form bg-light p-3">
                <form action="code.php" method="post" enctype="multipart/form-data">
                    <input type="file" name="excel" id="excel" class="form-inline">
                    <button type="submit" name="btn" class="form-inline btn btn-primary">Upload Excel</button>
                </form>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>sn</th>
                        <th>Name</th>
                        <th>Days</th>
                        <th>Income</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $show_data = "SELECT * FROM `excel`";
                    $show_data_result = mysqli_query($con, $show_data);
                    if ($show_data_result) {
                        foreach ($show_data_result as $data) {
                    ?>
                            <tr>
                                <td><?= $data['sn']; ?></td>
                                <td><?= $data['name']; ?></td>
                                <td><?= $data['days']; ?></td>
                                <td><?= $data['income']; ?></td>
                            </tr>
                    <?php
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>