<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "import_data");

require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;

if (isset($_POST['btn'])) {
    $allowed_ext = ['xls', 'csv', 'xlsx'];
    $file_name = $_FILES['excel']['name'];
    $checking = explode(".", $file_name);
    $file_ext = strtolower(end($checking));

    if (in_array($file_ext, $allowed_ext)) {
        $target_file = $_FILES['excel']['tmp_name'];
        $spreadsheet = IOFactory::load($target_file);
        $data = $spreadsheet->getActiveSheet()->toArray();

        $isInsertedOrUpdated = false; // Track if any data is inserted/updated

        foreach ($data as $key => $row) {
            // Skip the first row if it's a header
            if ($key === 0) continue;

            $sn = $row[0];
            $name = $row[1];
            $days = $row[2];
            $income = $row[3];

            // Sanitize values before using them in queries
            $sn = mysqli_real_escape_string($con, $sn);
            $name = mysqli_real_escape_string($con, $name);
            $days = mysqli_real_escape_string($con, $days);
            $income = mysqli_real_escape_string($con, $income);

            // Check if the record already exists
            $check_db = "SELECT sn FROM excel WHERE name = '$name'";
            $check_db_result = mysqli_query($con, $check_db);

            if (mysqli_num_rows($check_db_result) > 0) {
                // Update the existing record
                $update_data = "UPDATE `excel` SET `name`='$name', `days`='$days', `income`='$income' WHERE sn = '$sn'";
                mysqli_query($con, $update_data);
            } else {
                // Insert a new record
                $insert_data = "INSERT INTO `excel` (`name`, `days`, `income`) VALUES ('$name', '$days', '$income')";
                mysqli_query($con, $insert_data);
            }

            $isInsertedOrUpdated = true;
        }

        if ($isInsertedOrUpdated) {
            $_SESSION['status'] = "File Imported Successfully";
        } else {
            $_SESSION['status'] = "No Data Imported";
        }
        header('location: index.php');
        exit(0);

    } else {
        $_SESSION['status'] = "Invalid File Format";
        header('location: index.php');
        exit(0);
    }
}
